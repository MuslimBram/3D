const express = require('express');
const multer = require('multer');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const { PrismaClient } = require('@prisma/client');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();
const prisma = new PrismaClient();

// Multer config for 360° photos
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/panoramas/');
  },
  filename: (req, file, cb) => {
    cb(null, `${uuidv4()}${path.extname(file.originalname)}`);
  }
});

const upload = multer({ 
  storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files allowed'));
    }
  }
});

// Create business
router.post('/', authMiddleware, upload.single('panorama'), async (req, res) => {
  try {
    const { name, description, type } = req.body;
    const panoramaUrl = req.file ? `/uploads/panoramas/${req.file.filename}` : null;

    const business = await prisma.business.create({
      data: {
        name,
        description,
        type,
        ownerId: req.user.id,
        panoramaUrl
      }
    });

    res.json(business);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get all businesses (public)
router.get('/', async (req, res) => {
  try {
    const businesses = await prisma.business.findMany({
      include: {
        owner: { select: { id: true, name: true } },
        products: true
      }
    });
    res.json(businesses);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get single business
router.get('/:id', async (req, res) => {
  try {
    const business = await prisma.business.findUnique({
      where: { id: req.params.id },
      include: {
        owner: { select: { id: true, name: true } },
        products: true
      }
    });

    if (!business) {
      return res.status(404).json({ error: 'Business not found' });
    }

    res.json(business);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update business (owner only)
router.put('/:id', authMiddleware, async (req, res) => {
  try {
    const business = await prisma.business.findUnique({
      where: { id: req.params.id }
    });

    if (!business || business.ownerId !== req.user.id) {
      return res.status(403).json({ error: 'Not authorized' });
    }

    const updated = await prisma.business.update({
      where: { id: req.params.id },
      data: req.body
    });

    res.json(updated);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
