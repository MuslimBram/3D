const express = require('express');
const axios = require('axios');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();

const MESHY_API_KEY = process.env.MESHY_API_KEY;
const SKETCHFAB_API_TOKEN = process.env.SKETCHFAB_API_TOKEN;

// Generate 3D model with Meshy AI (Text to 3D)
router.post('/generate-3d', authMiddleware, async (req, res) => {
  try {
    const { prompt, mode = 'text-to-3d' } = req.body;

    if (!MESHY_API_KEY || MESHY_API_KEY === 'demo_key') {
      // Demo mode - return mock data
      return res.json({
        success: true,
        demo: true,
        taskId: 'demo-task-' + Date.now(),
        message: 'Demo mode: Add MESHY_API_KEY to .env for real generation',
        previewUrl: null,
        modelUrl: null
      });
    }

    // Meshy API v2 - Text to 3D
    const response = await axios.post(
      'https://api.meshy.ai/v2/text-to-3d',
      {
        mode,
        prompt,
        art_style: 'realistic',
        negative_prompt: 'low quality, blurry',
        topology: 'triangle-mesh'
      },
      {
        headers: {
          'Authorization': `Bearer ${MESHY_API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );

    res.json({
      success: true,
      taskId: response.data.result,
      message: '3D generation started. Poll /ai/status/:taskId for progress.'
    });
  } catch (error) {
    console.error('Meshy API Error:', error.response?.data || error.message);
    res.status(500).json({ 
      error: 'AI generation failed',
      details: error.response?.data || error.message 
    });
  }
});

// Check generation status
router.get('/status/:taskId', authMiddleware, async (req, res) => {
  try {
    if (req.params.taskId.startsWith('demo-task')) {
      return res.json({
        status: 'SUCCEEDED',
        progress: 100,
        modelUrl: null,
        message: 'Demo mode - no actual model generated'
      });
    }

    const response = await axios.get(
      `https://api.meshy.ai/v2/text-to-3d/${req.params.taskId}`,
      {
        headers: { 'Authorization': `Bearer ${MESHY_API_KEY}` }
      }
    );

    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Search Sketchfab models
router.get('/search-sketchfab', async (req, res) => {
  try {
    const { query, limit = 10 } = req.query;

    const response = await axios.get(
      'https://api.sketchfab.com/v3/search',
      {
        params: {
          type: 'models',
          q: query,
          count: limit,
          downloadable: true
        },
        headers: SKETCHFAB_API_TOKEN && SKETCHFAB_API_TOKEN !== 'demo_token' 
          ? { 'Authorization': `Token ${SKETCHFAB_API_TOKEN}` }
          : {}
      }
    );

    const models = response.data.results?.map(m => ({
      id: m.uid,
      name: m.name,
      thumbnail: m.thumbnails?.images?.[0]?.url,
      embedUrl: m.embedUrl,
      viewUrl: m.viewerUrl,
      author: m.user?.displayName
    })) || [];

    res.json({ models });
  } catch (error) {
    console.error('Sketchfab Error:', error.message);
    // Return demo data if API fails
    res.json({
      demo: true,
      models: [
        { id: 'demo-1', name: 'Modern Chair', thumbnail: null, viewUrl: '#' },
        { id: 'demo-2', name: 'Coffee Table', thumbnail: null, viewUrl: '#' },
        { id: 'demo-3', name: 'Lamp', thumbnail: null, viewUrl: '#' }
      ]
    });
  }
});

module.exports = router;
