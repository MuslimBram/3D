const express = require('express');
const { PrismaClient } = require('@prisma/client');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();
const prisma = new PrismaClient();

// Create product
router.post('/', authMiddleware, async (req, res) => {
  try {
    const {
      name, description, price, currency,
      expiryDate, batchNumber, model3DUrl,
      model3DData, aiGenerated, aiPrompt, aiSource,
      businessId
    } = req.body;

    // Verify ownership
    const business = await prisma.business.findUnique({
      where: { id: businessId }
    });

    if (!business || business.ownerId !== req.user.id) {
      return res.status(403).json({ error: 'Not authorized' });
    }

    const product = await prisma.product.create({
      data: {
        name,
        description,
        price: price ? parseFloat(price) : null,
        currency,
        expiryDate: expiryDate ? new Date(expiryDate) : null,
        batchNumber,
        model3DUrl,
        model3DData,
        aiGenerated,
        aiPrompt,
        aiSource,
        businessId
      }
    });

    res.json(product);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get products by business
router.get('/business/:businessId', async (req, res) => {
  try {
    const products = await prisma.product.findMany({
      where: { businessId: req.params.businessId }
    });
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update product (position, etc.)
router.put('/:id', authMiddleware, async (req, res) => {
  try {
    const product = await prisma.product.findUnique({
      where: { id: req.params.id },
      include: { business: true }
    });

    if (!product || product.business.ownerId !== req.user.id) {
      return res.status(403).json({ error: 'Not authorized' });
    }

    const updated = await prisma.product.update({
      where: { id: req.params.id },
      data: req.body
    });

    res.json(updated);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete product
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    const product = await prisma.product.findUnique({
      where: { id: req.params.id },
      include: { business: true }
    });

    if (!product || product.business.ownerId !== req.user.id) {
      return res.status(403).json({ error: 'Not authorized' });
    }

    await prisma.product.delete({ where: { id: req.params.id } });
    res.json({ message: 'Product deleted' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
