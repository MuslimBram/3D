# Virtual Business 3D 🏪

Platformë WebApp për krijimin e bizneseve virtuale 3D nga foto 360°, me produkte 3D të gjeneruara nga AI.

## 🚀 Veçoritë

- 📸 Ngarkim dhe shfaqje e fotove 360° (sferike)
- 🤖 Gjenerim i produkteve 3D me Meshy AI (text/image → 3D)
- 🎨 Editor 3D për vendosjen e produkteve në ambient
- 🔍 Kërkim modelesh 3D nga Sketchfab
- 📱 Responsive (përshtatet për mobile)
- 🗄️ Menaxhim produktesh me data skadence

## 📁 Struktura e Projektit

```
virtual-business-3d/
├── frontend/          # Next.js 14 + Three.js
├── backend/           # Node.js/Express API
├── docker-compose.yml # Nis të gjitha shërbimet
└── README.md
```

## 🛠️ Teknologjitë

| Shtresa | Teknologjia |
|---------|-------------|
| Frontend | Next.js 14, Three.js, React Three Fiber, TailwindCSS |
| Backend | Node.js, Express, Prisma, PostgreSQL |
| AI | Meshy AI API, Sketchfab API |
| 3D | Three.js, Pannellum, GLTF/GLB |

## 🏃‍♂️ Si ta nisësh

### Opsioni 1: Me Docker (Rekomandohet)

```bash
docker-compose up --build
```

Aplikacioni do të jetë në:
- Frontend: http://localhost:3000
- Backend API: http://localhost:4000

### Opsioni 2: Manualisht

1. **Backend:**
```bash
cd backend
npm install
npx prisma migrate dev
npm run dev
```

2. **Frontend:**
```bash
cd frontend
npm install
npm run dev
```

## ⚙️ Konfigurimi

Krijo file `.env` në `backend/`:

```env
DATABASE_URL="postgresql://postgres:postgres@localhost:5432/virtualbusiness"
MESHY_API_KEY="your_meshy_api_key"
SKETCHFAB_API_TOKEN="your_sketchfab_token"
JWT_SECRET="your_jwt_secret"
```

## 📝 API Keys

- **Meshy AI:** https://meshy.ai/api
- **Sketchfab:** https://sketchfab.com/developers

## 🗺️ Roadmap

- [x] MVP WebApp
- [x] 360° Viewer
- [x] AI 3D Generation (Meshy)
- [x] 3D Editor
- [ ] iOS App (React Native)
- [ ] Android App (React Native)
- [ ] AR/VR Support
- [ ] Gaussian Splatting për ambientet

## 📄 Licenca

MIT
