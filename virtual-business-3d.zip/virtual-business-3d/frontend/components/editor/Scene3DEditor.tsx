'use client';

import { useState, useRef, Suspense } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Grid, TransformControls, useGLTF, GizmoHelper, GizmoViewport } from '@react-three/drei';
import * as THREE from 'three';

interface Product {
  id: string;
  name: string;
  model3DUrl: string | null;
  model3DData: {
    position: [number, number, number];
    rotation: [number, number, number];
    scale: [number, number, number];
  } | null;
}

interface Scene3DEditorProps {
  products: Product[];
  selectedProduct: Product | null;
  onSelectProduct: (product: Product | null) => void;
  onUpdateTransform: (productId: string, transform: any) => void;
}

function ProductMesh({ 
  product, 
  isSelected, 
  onClick,
  onTransformChange
}: { 
  product: Product; 
  isSelected: boolean;
  onClick: () => void;
  onTransformChange: (transform: any) => void;
}) {
  const meshRef = useRef<THREE.Group>(null);
  const transformRef = useRef<any>(null);

  const transform = product.model3DData || {
    position: [0, 0, 0],
    rotation: [0, 0, 0],
    scale: [1, 1, 1]
  };

  // Try to load GLB if available
  let model = null;
  try {
    if (product.model3DUrl) {
      // eslint-disable-next-line react-hooks/rules-of-hooks
      const gltf = useGLTF(product.model3DUrl);
      model = gltf.scene;
    }
  } catch (e) {
    // Fallback to box
  }

  return (
    <group 
      ref={meshRef}
      position={new THREE.Vector3(...transform.position)}
      rotation={new THREE.Euler(...transform.rotation)}
      scale={new THREE.Vector3(...transform.scale)}
    >
      {isSelected && (
        <TransformControls
          ref={transformRef}
          mode="translate"
          onObjectChange={() => {
            if (meshRef.current) {
              const pos = meshRef.current.position;
              const rot = meshRef.current.rotation;
              const scl = meshRef.current.scale;
              onTransformChange({
                position: [pos.x, pos.y, pos.z],
                rotation: [rot.x, rot.y, rot.z],
                scale: [scl.x, scl.y, scl.z]
              });
            }
          }}
        />
      )}

      <group onClick={(e) => {
        e.stopPropagation();
        onClick();
      }}>
        {model ? (
          <primitive object={model.clone()} />
        ) : (
          <mesh>
            <boxGeometry args={[0.5, 0.5, 0.5]} />
            <meshStandardMaterial 
              color={isSelected ? '#3b82f6' : '#6b7280'} 
              wireframe={!isSelected}
            />
          </mesh>
        )}

        {/* Selection highlight */}
        {isSelected && (
          <mesh>
            <boxGeometry args={[0.6, 0.6, 0.6]} />
            <meshBasicMaterial color="#3b82f6" wireframe transparent opacity={0.5} />
          </mesh>
        )}
      </group>
    </group>
  );
}

function Scene({ 
  products, 
  selectedProduct, 
  onSelectProduct, 
  onUpdateTransform 
}: Scene3DEditorProps) {
  return (
    <>
      <ambientLight intensity={0.4} />
      <directionalLight position={[5, 5, 5]} intensity={1} castShadow />
      <pointLight position={[-5, 5, -5]} intensity={0.5} />

      <Grid 
        position={[0, -0.01, 0]} 
        args={[20, 20]} 
        cellSize={1} 
        cellThickness={0.5} 
        cellColor="#374151"
        sectionSize={5}
        sectionThickness={1}
        sectionColor="#4b5563"
        fadeDistance={25}
        infiniteGrid
      />

      {products.map((product) => (
        <ProductMesh
          key={product.id}
          product={product}
          isSelected={selectedProduct?.id === product.id}
          onClick={() => onSelectProduct(
            selectedProduct?.id === product.id ? null : product
          )}
          onTransformChange={(transform) => onUpdateTransform(product.id, transform)}
        />
      ))}

      <OrbitControls makeDefault />
      <GizmoHelper alignment="bottom-right" margin={[80, 80]}>
        <GizmoViewport axisColors={['red', 'green', 'blue']} labelColor="white" />
      </GizmoHelper>
    </>
  );
}

export default function Scene3DEditor(props: Scene3DEditorProps) {
  return (
    <Canvas
      camera={{ position: [5, 5, 5], fov: 50 }}
      style={{ background: '#111827' }}
      shadows
      onPointerMissed={() => props.onSelectProduct(null)}
    >
      <Suspense fallback={null}>
        <Scene {...props} />
      </Suspense>
    </Canvas>
  );
}
