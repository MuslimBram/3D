'use client';

import { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Environment, ContactShadows, useGLTF, Center } from '@react-three/drei';

interface Product3DViewerProps {
  modelUrl: string | null;
}

function Model({ url }: { url: string }) {
  try {
    const { scene } = useGLTF(url);
    return (
      <Center>
        <primitive object={scene} scale={1.5} />
      </Center>
    );
  } catch (e) {
    return (
      <mesh>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color="#3b82f6" wireframe />
      </mesh>
    );
  }
}

function FallbackModel() {
  return (
    <Center>
      <mesh rotation={[0.5, 0.5, 0]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color="#3b82f6" wireframe />
      </mesh>
      <mesh rotation={[0.5, 0.5, 0]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color="#8b5cf6" transparent opacity={0.3} />
      </mesh>
    </Center>
  );
}

export default function Product3DViewer({ modelUrl }: Product3DViewerProps) {
  return (
    <Canvas
      camera={{ position: [3, 3, 3], fov: 50 }}
      style={{ background: 'linear-gradient(to bottom, #1a1a2e, #16213e)' }}
    >
      <ambientLight intensity={0.5} />
      <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={1} />
      <pointLight position={[-10, -10, -10]} intensity={0.5} />

      <Suspense fallback={<FallbackModel />}>
        {modelUrl ? (
          <Model url={modelUrl} />
        ) : (
          <FallbackModel />
        )}
        <Environment preset="city" />
        <ContactShadows position={[0, -1.5, 0]} opacity={0.5} scale={10} blur={2} />
      </Suspense>

      <OrbitControls 
        autoRotate 
        autoRotateSpeed={2}
        enablePan={false}
        minDistance={2}
        maxDistance={10}
      />
    </Canvas>
  );
}
