'use client';

import { useEffect, useRef } from 'react';

interface PanoramaViewerProps {
  imageUrl: string;
  hotspots?: Array<{
    pitch: number;
    yaw: number;
    text: string;
  }>;
}

export default function PanoramaViewer({ imageUrl, hotspots = [] }: PanoramaViewerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const viewerRef = useRef<any>(null);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    // Dynamic import pannellum
    const loadPannellum = async () => {
      const pannellum = await import('pannellum-react');

      if (containerRef.current && !viewerRef.current) {
        // Using pannellum-react Pannellum component
        // For simplicity, we'll use the native pannellum viewer
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/pannellum@2.5.6/build/pannellum.js';
        script.onload = () => {
          const link = document.createElement('link');
          link.rel = 'stylesheet';
          link.href = 'https://cdn.jsdelivr.net/npm/pannellum@2.5.6/build/pannellum.css';
          document.head.appendChild(link);

          // @ts-ignore
          viewerRef.current = window.pannellum.viewer(containerRef.current, {
            type: 'equirectangular',
            panorama: imageUrl,
            autoLoad: true,
            showControls: true,
            compass: true,
            title: 'Virtual Tour',
            hotSpots: hotspots.map((h, i) => ({
              pitch: h.pitch,
              yaw: h.yaw,
              type: 'info',
              text: h.text,
              id: `hotspot-${i}`
            }))
          });
        };
        document.head.appendChild(script);
      }
    };

    loadPannellum();

    return () => {
      if (viewerRef.current) {
        viewerRef.current.destroy();
        viewerRef.current = null;
      }
    };
  }, [imageUrl, hotspots]);

  return (
    <div 
      ref={containerRef} 
      style={{ width: '100%', height: '100%' }}
      className="rounded-lg overflow-hidden"
    />
  );
}
