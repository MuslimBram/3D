'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import axios from 'axios';
import { Upload, Building2, FileText, Tag } from 'lucide-react';

const businessTypes = [
  'RESTAURANT', 'CAFE', 'SHOP', 'PHARMACY', 
  'CLINIC', 'SUPERMARKET', 'BAKERY', 'OTHER'
];

export default function CreateBusiness() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    name: '',
    description: '',
    type: 'SHOP'
  });
  const [panorama, setPanorama] = useState<File | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!panorama) return;

    setLoading(true);
    try {
      const data = new FormData();
      data.append('name', form.name);
      data.append('description', form.description);
      data.append('type', form.type);
      data.append('panorama', panorama);

      const token = localStorage.getItem('token');
      await axios.post('/api/businesses', data, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'Authorization': `Bearer ${token}`
        }
      });

      router.push('/');
    } catch (error) {
      console.error('Error creating business:', error);
      alert('Gabim gjatë krijimit. Sigurohu që je i loguar.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 py-8">
      <div className="max-w-2xl mx-auto px-4">
        <h1 className="text-3xl font-bold mb-8">Krijo Biznes të Ri 3D</h1>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Name */}
          <div>
            <label className="flex items-center gap-2 text-sm font-medium mb-2">
              <Building2 className="w-4 h-4" />
              Emri i Biznesit
            </label>
            <input
              type="text"
              required
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg focus:border-blue-500 focus:outline-none"
              placeholder="p.sh. Bar Kafe "Liri""
            />
          </div>

          {/* Type */}
          <div>
            <label className="flex items-center gap-2 text-sm font-medium mb-2">
              <Tag className="w-4 h-4" />
              Lloji
            </label>
            <select
              value={form.type}
              onChange={(e) => setForm({ ...form, type: e.target.value })}
              className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg focus:border-blue-500 focus:outline-none"
            >
              {businessTypes.map(t => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>

          {/* Description */}
          <div>
            <label className="flex items-center gap-2 text-sm font-medium mb-2">
              <FileText className="w-4 h-4" />
              Përshkrimi
            </label>
            <textarea
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg focus:border-blue-500 focus:outline-none h-32"
              placeholder="Përshkruaj biznesin tënd..."
            />
          </div>

          {/* Panorama Upload */}
          <div>
            <label className="flex items-center gap-2 text-sm font-medium mb-2">
              <Upload className="w-4 h-4" />
              Foto 360° (Equirectangular)
            </label>
            <div className="border-2 border-dashed border-gray-700 rounded-lg p-8 text-center hover:border-blue-500 transition-colors">
              <input
                type="file"
                accept="image/*"
                required
                onChange={(e) => setPanorama(e.target.files?.[0] || null)}
                className="hidden"
                id="panorama-upload"
              />
              <label htmlFor="panorama-upload" className="cursor-pointer">
                <Upload className="w-12 h-12 text-gray-500 mx-auto mb-3" />
                <p className="text-gray-400">
                  {panorama ? panorama.name : 'Kliko për të ngarkuar foto 360°'}
                </p>
                <p className="text-gray-600 text-sm mt-1">
                  Format: JPG, PNG (max 50MB)
                </p>
              </label>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading || !panorama}
            className="w-full py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-700 rounded-lg font-semibold transition-colors"
          >
            {loading ? 'Duke krijuar...' : 'Krijo Biznesin'}
          </button>
        </form>
      </div>
    </div>
  );
}
