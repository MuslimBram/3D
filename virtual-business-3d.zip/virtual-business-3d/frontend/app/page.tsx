'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Store, Plus, Eye, Box } from 'lucide-react';
import axios from 'axios';

interface Business {
  id: string;
  name: string;
  description: string | null;
  type: string;
  panoramaUrl: string;
  _count?: { products: number };
}

export default function Home() {
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchBusinesses();
  }, []);

  const fetchBusinesses = async () => {
    try {
      const res = await axios.get('/api/businesses');
      setBusinesses(res.data);
    } catch (error) {
      console.error('Error fetching businesses:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800">
      {/* Header */}
      <header className="border-b border-gray-700 bg-gray-900/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Box className="w-8 h-8 text-blue-500" />
            <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
              Virtual Business 3D
            </h1>
          </div>
          <Link
            href="/create"
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors"
          >
            <Plus className="w-4 h-4" />
            Krijo Biznes
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4">
            Eksploro Biznese në <span className="text-blue-400">3D</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Shfleto biznese virtuale krijuar nga foto 360°. Shiko produktet në 3D,
            eksploro ambjentet dhe përjetoji nga afër.
          </p>
        </div>

        {loading ? (
          <div className="flex justify-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {businesses.map((business) => (
              <BusinessCard key={business.id} business={business} />
            ))}
          </div>
        )}

        {!loading && businesses.length === 0 && (
          <div className="text-center py-20">
            <Store className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-400">
              Asnjë biznes nuk u gjet
            </h3>
            <p className="text-gray-500 mt-2">
              Ji i pari që krijon një biznes virtual 3D!
            </p>
          </div>
        )}
      </main>
    </div>
  );
}

function BusinessCard({ business }: { business: Business }) {
  return (
    <div className="bg-gray-800 rounded-xl overflow-hidden border border-gray-700 hover:border-blue-500 transition-all hover:shadow-xl hover:shadow-blue-500/10">
      <div className="h-48 bg-gradient-to-br from-blue-900/50 to-purple-900/50 flex items-center justify-center relative">
        {business.panoramaUrl ? (
          <img
            src={business.panoramaUrl}
            alt={business.name}
            className="w-full h-full object-cover opacity-60"
          />
        ) : (
          <Store className="w-16 h-16 text-gray-600" />
        )}
        <div className="absolute top-3 right-3 px-3 py-1 bg-blue-600/80 rounded-full text-xs font-medium">
          {business.type}
        </div>
      </div>

      <div className="p-5">
        <h3 className="text-xl font-bold mb-2">{business.name}</h3>
        <p className="text-gray-400 text-sm mb-4 line-clamp-2">
          {business.description || 'Pa përshkrim'}
        </p>

        <div className="flex gap-3">
          <Link
            href={`/business/${business.id}`}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors text-sm"
          >
            <Eye className="w-4 h-4" />
            Shiko
          </Link>
          <Link
            href={`/editor/${business.id}`}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors text-sm"
          >
            <Box className="w-4 h-4" />
            Edito
          </Link>
        </div>
      </div>
    </div>
  );
}
