'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import axios from 'axios';
import dynamic from 'next/dynamic';
import { Save, Plus, Wand2, Search, Trash2, RotateCcw } from 'lucide-react';

const Scene3DEditor = dynamic(() => import('@/components/editor/Scene3DEditor'), {
  ssr: false,
  loading: () => <div className="h-[70vh] bg-gray-800 animate-pulse" />
});

interface Product {
  id: string;
  name: string;
  model3DUrl: string | null;
  model3DData: {
    position: [number, number, number];
    rotation: [number, number, number];
    scale: [number, number, number];
  } | null;
}

interface Business {
  id: string;
  name: string;
  panoramaUrl: string;
  products: Product[];
}

export default function EditorPage() {
  const { id } = useParams();
  const [business, setBusiness] = useState<Business | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('');
  const [generating, setGenerating] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);

  useEffect(() => {
    fetchBusiness();
  }, [id]);

  const fetchBusiness = async () => {
    try {
      const res = await axios.get(`/api/businesses/${id}`);
      setBusiness(res.data);
      setProducts(res.data.products || []);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const handleGenerateAI = async () => {
    if (!aiPrompt.trim()) return;
    setGenerating(true);
    try {
      const token = localStorage.getItem('token');
      const res = await axios.post('/ai/generate-3d', 
        { prompt: aiPrompt },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      if (res.data.demo) {
        // Demo mode - create product with placeholder
        await createProduct({
          name: aiPrompt,
          model3DUrl: null,
          aiGenerated: true,
          aiPrompt,
          aiSource: 'meshy'
        });
      }

      setAiPrompt('');
      setShowAddModal(false);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setGenerating(false);
    }
  };

  const handleSearchSketchfab = async () => {
    try {
      const res = await axios.get(`/ai/search-sketchfab?query=${searchQuery}`);
      setSearchResults(res.data.models || []);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const createProduct = async (data: any) => {
    try {
      const token = localStorage.getItem('token');
      await axios.post('/api/products', {
        ...data,
        businessId: id,
        model3DData: {
          position: [0, 0, 0],
          rotation: [0, 0, 0],
          scale: [1, 1, 1]
        }
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      fetchBusiness();
    } catch (error) {
      console.error('Error creating product:', error);
    }
  };

  const updateProductTransform = async (productId: string, transform: any) => {
    try {
      const token = localStorage.getItem('token');
      await axios.put(`/api/products/${productId}`, {
        model3DData: transform
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const deleteProduct = async (productId: string) => {
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`/api/products/${productId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      fetchBusiness();
    } catch (error) {
      console.error('Error:', error);
    }
  };

  if (!business) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Toolbar */}
      <div className="bg-gray-800 border-b border-gray-700 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <h1 className="text-xl font-bold">Editor: {business.name}</h1>
          <span className="text-gray-500">|</span>
          <span className="text-gray-400 text-sm">{products.length} produkte</span>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors"
          >
            <Plus className="w-4 h-4" />
            Shto Produkt
          </button>
        </div>
      </div>

      <div className="flex h-[calc(100vh-64px)]">
        {/* 3D Editor */}
        <div className="flex-1">
          <Scene3DEditor
            products={products}
            selectedProduct={selectedProduct}
            onSelectProduct={setSelectedProduct}
            onUpdateTransform={updateProductTransform}
          />
        </div>

        {/* Sidebar */}
        <div className="w-80 bg-gray-800 border-l border-gray-700 p-4 overflow-auto">
          <h2 className="font-bold mb-4">Produktet në Skenë</h2>

          {products.map((product) => (
            <div
              key={product.id}
              onClick={() => setSelectedProduct(product)}
              className={`p-3 rounded-lg mb-2 cursor-pointer flex items-center justify-between ${
                selectedProduct?.id === product.id
                  ? 'bg-blue-500/20 border border-blue-500'
                  : 'bg-gray-700/50 border border-transparent hover:border-gray-600'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gray-600 rounded-lg flex items-center justify-center">
                  <Box className="w-5 h-5 text-gray-400" />
                </div>
                <div>
                  <p className="font-medium text-sm">{product.name}</p>
                  {product.aiGenerated && (
                    <span className="text-xs text-purple-400">AI Generated</span>
                  )}
                </div>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  deleteProduct(product.id);
                }}
                className="p-1 hover:bg-red-500/20 hover:text-red-400 rounded transition-colors"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}

          {selectedProduct && (
            <div className="mt-6 p-4 bg-gray-700/30 rounded-lg border border-gray-600">
              <h3 className="font-semibold mb-3">Transformimi</h3>
              <TransformControls
                product={selectedProduct}
                onUpdate={(transform) => updateProductTransform(selectedProduct.id, transform)}
              />
            </div>
          )}
        </div>
      </div>

      {/* Add Product Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="bg-gray-800 rounded-xl max-w-lg w-full p-6">
            <h2 className="text-2xl font-bold mb-6">Shto Produkt të Ri</h2>

            {/* AI Generation */}
            <div className="mb-6">
              <label className="flex items-center gap-2 text-sm font-medium mb-2">
                <Wand2 className="w-4 h-4 text-purple-400" />
                Gjenero me AI (Meshy)
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={aiPrompt}
                  onChange={(e) => setAiPrompt(e.target.value)}
                  placeholder="p.sh. A modern red chair..."
                  className="flex-1 px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg focus:border-blue-500 focus:outline-none"
                />
                <button
                  onClick={handleGenerateAI}
                  disabled={generating}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-700 disabled:bg-gray-600 rounded-lg transition-colors"
                >
                  {generating ? '...' : 'Gjenero'}
                </button>
              </div>
            </div>

            {/* Sketchfab Search */}
            <div className="mb-6">
              <label className="flex items-center gap-2 text-sm font-medium mb-2">
                <Search className="w-4 h-4 text-blue-400" />
                Kërko në Sketchfab
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Kërko modele 3D..."
                  className="flex-1 px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg focus:border-blue-500 focus:outline-none"
                />
                <button
                  onClick={handleSearchSketchfab}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors"
                >
                  Kërko
                </button>
              </div>

              {searchResults.length > 0 && (
                <div className="mt-3 space-y-2 max-h-48 overflow-auto">
                  {searchResults.map((model) => (
                    <div
                      key={model.id}
                      onClick={() => {
                        createProduct({
                          name: model.name,
                          model3DUrl: model.viewUrl,
                          aiGenerated: false,
                          aiSource: 'sketchfab'
                        });
                        setShowAddModal(false);
                      }}
                      className="p-3 bg-gray-700 rounded-lg hover:bg-gray-600 cursor-pointer flex items-center gap-3"
                    >
                      {model.thumbnail && (
                        <img src={model.thumbnail} alt="" className="w-12 h-12 rounded object-cover" />
                      )}
                      <div>
                        <p className="font-medium text-sm">{model.name}</p>
                        <p className="text-xs text-gray-400">{model.author}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <button
              onClick={() => setShowAddModal(false)}
              className="w-full py-2 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors"
            >
              Mbyll
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function TransformControls({ product, onUpdate }: { product: Product; onUpdate: (t: any) => void }) {
  const [transform, setTransform] = useState(product.model3DData || {
    position: [0, 0, 0],
    rotation: [0, 0, 0],
    scale: [1, 1, 1]
  });

  const handleChange = (field: string, axis: number, value: number) => {
    const newTransform = { ...transform };
    (newTransform as any)[field][axis] = value;
    setTransform(newTransform);
    onUpdate(newTransform);
  };

  return (
    <div className="space-y-4">
      {['position', 'rotation', 'scale'].map((field) => (
        <div key={field}>
          <label className="text-xs text-gray-400 uppercase font-semibold">{field}</label>
          <div className="grid grid-cols-3 gap-2 mt-1">
            {['X', 'Y', 'Z'].map((axis, i) => (
              <div key={axis} className="flex items-center gap-1">
                <span className="text-xs text-gray-500 w-3">{axis}</span>
                <input
                  type="number"
                  step={field === 'scale' ? 0.1 : 0.5}
                  value={(transform as any)[field][i]}
                  onChange={(e) => handleChange(field, i, parseFloat(e.target.value))}
                  className="w-full px-2 py-1 bg-gray-800 border border-gray-600 rounded text-sm"
                />
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

function Box({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" />
      <polyline points="3.27 6.96 12 12.01 20.73 6.96" />
      <line x1="12" y1="22.08" x2="12" y2="12" />
    </svg>
  );
}
