'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import axios from 'axios';
import dynamic from 'next/dynamic';
import { ArrowLeft, Box, Calendar, AlertTriangle } from 'lucide-react';
import Link from 'next/link';

const PanoramaViewer = dynamic(() => import('@/components/panorama/PanoramaViewer'), {
  ssr: false,
  loading: () => <div className="h-[60vh] bg-gray-800 animate-pulse rounded-xl" />
});

const Product3DViewer = dynamic(() => import('@/components/three/Product3DViewer'), {
  ssr: false
});

interface Product {
  id: string;
  name: string;
  description: string | null;
  price: number | null;
  currency: string;
  expiryDate: string | null;
  model3DUrl: string | null;
  model3DData: any;
  aiGenerated: boolean;
}

interface Business {
  id: string;
  name: string;
  description: string | null;
  type: string;
  panoramaUrl: string;
  products: Product[];
}

export default function BusinessPage() {
  const { id } = useParams();
  const [business, setBusiness] = useState<Business | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchBusiness();
  }, [id]);

  const fetchBusiness = async () => {
    try {
      const res = await axios.get(`/api/businesses/${id}`);
      setBusiness(res.data);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const isExpired = (date: string | null) => {
    if (!date) return false;
    return new Date(date) < new Date();
  };

  const isNearExpiry = (date: string | null) => {
    if (!date) return false;
    const daysUntil = Math.ceil((new Date(date).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
    return daysUntil > 0 && daysUntil <= 7;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500" />
      </div>
    );
  }

  if (!business) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <p className="text-gray-400">Biznesi nuk u gjet</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <header className="bg-gray-800 border-b border-gray-700 px-4 py-4">
        <div className="max-w-7xl mx-auto flex items-center gap-4">
          <Link href="/" className="p-2 hover:bg-gray-700 rounded-lg transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div>
            <h1 className="text-2xl font-bold">{business.name}</h1>
            <p className="text-gray-400 text-sm">{business.type} • {business.products.length} produkte</p>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Panorama Viewer */}
        <div className="lg:col-span-2">
          <div className="bg-gray-800 rounded-xl overflow-hidden border border-gray-700">
            <div className="h-[60vh]">
              {business.panoramaUrl && (
                <PanoramaViewer imageUrl={`http://localhost:4000${business.panoramaUrl}`} />
              )}
            </div>
          </div>
        </div>

        {/* Products Sidebar */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Box className="w-5 h-5 text-blue-500" />
            Produktet
          </h2>

          {business.products.map((product) => (
            <div
              key={product.id}
              onClick={() => setSelectedProduct(product)}
              className={`p-4 rounded-lg border cursor-pointer transition-all ${
                selectedProduct?.id === product.id
                  ? 'border-blue-500 bg-blue-500/10'
                  : 'border-gray-700 bg-gray-800 hover:border-gray-600'
              }`}
            >
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-semibold">{product.name}</h3>
                  {product.price && (
                    <p className="text-blue-400 font-medium">
                      {product.price} {product.currency}
                    </p>
                  )}
                </div>
                {product.aiGenerated && (
                  <span className="px-2 py-1 bg-purple-500/20 text-purple-400 text-xs rounded-full">
                    AI
                  </span>
                )}
              </div>

              {/* Expiry Warning */}
              {product.expiryDate && (
                <div className={`mt-2 flex items-center gap-2 text-sm ${
                  isExpired(product.expiryDate) ? 'text-red-400' :
                  isNearExpiry(product.expiryDate) ? 'text-yellow-400' : 'text-gray-500'
                }`}>
                  <Calendar className="w-4 h-4" />
                  <span>
                    {isExpired(product.expiryDate) ? (
                      <span className="flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" />
                        Skaduar!
                      </span>
                    ) : (
                      `Skadon: ${new Date(product.expiryDate).toLocaleDateString('sq-AL')}`
                    )}
                  </span>
                </div>
              )}
            </div>
          ))}

          {business.products.length === 0 && (
            <p className="text-gray-500 text-center py-8">
              Nuk ka produkte ende.
            </p>
          )}
        </div>
      </div>

      {/* 3D Product Modal */}
      {selectedProduct && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="bg-gray-800 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-bold">{selectedProduct.name}</h2>
                <button
                  onClick={() => setSelectedProduct(null)}
                  className="p-2 hover:bg-gray-700 rounded-lg"
                >
                  ✕
                </button>
              </div>

              <div className="h-[50vh] bg-gray-900 rounded-lg mb-4">
                <Product3DViewer modelUrl={selectedProduct.model3DUrl} />
              </div>

              <p className="text-gray-400 mb-4">{selectedProduct.description}</p>

              {selectedProduct.price && (
                <p className="text-2xl font-bold text-blue-400">
                  {selectedProduct.price} {selectedProduct.currency}
                </p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
